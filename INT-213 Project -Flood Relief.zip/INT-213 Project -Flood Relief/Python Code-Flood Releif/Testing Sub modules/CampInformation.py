from tkinter import *
import sqlite3


def campinformation():
    # connect database
    con = sqlite3.connect('camp_database.db')

    # create cursor
    c = con.cursor()

    # create table
    '''
    c.execute(""" CREATE TABLE camp1 (
        name text,
        address text,
        caddress text,
        phone1 integer,
        phone2 integer,
        adhar integer,
        dob text,
        blood text,
        birthmark text,
        medical text,
        campinfo text,
        dateofarrival text
        )""")
    '''

    def submit():
        # connect database
        con = sqlite3.connect('camp_database.db')

        # create cursor
        c = con.cursor()

        # Insert into table
        c.execute(
            "INSERT INTO camp1 VALUES(:name, :address, :caddress, :phone1, :phone2, :adhar, :dob, :blood, :birthmark, :medical, :campinfo, :dateofarrival)",

            {
                'name': input_name.get(),
                'address': input_address.get(),
                'caddress': input_caddress.get(),
                'phone1': input_phone1.get(),
                'phone2': input_phone2.get(),
                'adhar': input_adhar.get(),
                'dob': input_dob.get(),
                'blood': input_blood.get(),
                'birthmark': input_birthmark.get(),
                'medical': input_medical.get(),
                'campinfo': input_camp.get(),
                'dateofarrival': input_dateofarrival.get()

            })

        con.commit()
        con.close()
        # clear the text boxes
        entry_name.delete(0, END)
        entry_address.delete(0, END)
        entry_caddress.delete(0, END)
        entry_phone1.delete(0, END)
        entry_phone2.delete(0, END)
        entry_adhar.delete(0, END)
        entry_dob.delete(0, END)
        entry_blood.delete(0, END)
        entry_birthmark.delete(0, END)
        entry_medical.delete(0, END)
        entry_camp.delete(0, END)
        entry_dateofarrival.delete(0, END)

    # For showing data of camp
    def showdata():
        root2 = Tk()
        root2.geometry("1500x900")
        root2.config(bg="bisque2")
        # connect database
        con = sqlite3.connect('camp_database.db')
        # create cursor
        c = con.cursor()
        # to display the database
        c.execute("SELECT * from camp1")
        record = c.fetchall()

        # loop through records
        print_data_name = ''
        print_data_address = ''
        print_data_phone1 = ''
        print_data_adhar = ''
        print_data_dob = ''
        print_data_blood = ''
        print_data_birthmark = ''
        print_data_medical = ''
        print_data_camp = ''
        print_data_dateofarrival = ''

        for records in record:
            print_data_name += str(records[0]) + " \n"
            print_data_address += str(records[1]) + "\n"
            print_data_phone1 += str(records[3]) + "\n"
            print_data_adhar += str(records[5]) + "\n"
            print_data_dob += str(records[6]) + "\n"
            print_data_blood += str(records[7]) + "\n"
            print_data_birthmark += str(records[8]) + "\n"
            print_data_medical += str(records[9]) + "\n"
            print_data_camp += str(records[10]) + "\n"
            print_data_dateofarrival += str(records[11]) + "\n"

        displaylabel_name = Label(root2, text=print_data_name, bg="bisque2", fg="black", font=("Helvetica", 10))
        displaylabel_address = Label(root2, text=print_data_address, bg="bisque2", fg="black", font=("Helvetica", 10))
        displaylabel_phone1 = Label(root2, text=print_data_phone1, bg="bisque2", fg="black", font=("Helvetica", 10))
        displaylabel_adhar = Label(root2, text=print_data_adhar, bg="bisque2", fg="black", font=("Helvetica", 10))
        displaylabel_dob = Label(root2, text=print_data_dob, bg="bisque2", fg="black", font=("Helvetica", 10))
        displaylabel_blood = Label(root2, text=print_data_blood, bg="bisque2", fg="black", font=("Helvetica", 10))
        displaylabel_birthmark = Label(root2, text=print_data_birthmark, bg="bisque2", fg="black",
                                       font=("Helvetica", 10))
        displaylabel_medical = Label(root2, text=print_data_medical, bg="bisque2", fg="black", font=("Helvetica", 10))
        displaylabel_camp = Label(root2, text=print_data_camp, bg="bisque2", fg="black", font=("Helvetica", 10))
        displaylabel_dateofarrival = Label(root2, text=print_data_dateofarrival, bg="bisque2", fg="black",
                                           font=("Helvetica", 10))

        Label(root2, text="Name", bg="bisque2", fg="black", font=("Helvetica", 15)).grid(row=0, column=1, padx=5,
                                                                                         pady=3)
        Label(root2, text="Address", bg="bisque2", fg="black", font=("Helvetica", 15)).grid(row=0, column=2, padx=5,
                                                                                            pady=3)

        Label(root2, text="Phone number 1", bg="bisque2", fg="black", font=("Helvetica", 15)).grid(row=0, column=3,
                                                                                                   padx=5, pady=3)
        Label(root2, text="Adhar Card ", bg="bisque2", fg="black", font=("Helvetica", 15)).grid(row=0, column=4,
                                                                                                padx=5, pady=3)
        Label(root2, text="Date of birth", bg="bisque2", fg="black", font=("Helvetica", 15)).grid(row=0, column=5,
                                                                                                  padx=5, pady=3)
        Label(root2, text="Blood Group", bg="bisque2", fg="black", font=("Helvetica", 15)).grid(row=0, column=6,
                                                                                                padx=5, pady=3)
        Label(root2, text="Birthmark", bg="bisque2", fg="black", font=("Helvetica", 15)).grid(row=0, column=7, padx=5,
                                                                                              pady=3)
        Label(root2, text="Medical", bg="bisque2", fg="black", font=("Helvetica", 15)).grid(row=0, column=8, padx=5,
                                                                                            pady=3)
        Label(root2, text="Camp Info.", bg="bisque2", fg="black", font=("Helvetica", 15)).grid(row=0, column=9,
                                                                                               padx=5, pady=3)
        Label(root2, text="Date of Arrival", bg="bisque2", fg="black", font=("Helvetica", 15)).grid(row=0, column=10,
                                                                                                    padx=5, pady=3)

        displaylabel_name.grid(row=1, column=1, padx=5, pady=5)
        displaylabel_address.grid(row=1, column=2, padx=5, pady=5)
        displaylabel_phone1.grid(row=1, column=3, padx=5, pady=5)
        displaylabel_adhar.grid(row=1, column=4, padx=5, pady=5)
        displaylabel_dob.grid(row=1, column=5, padx=5, pady=5)
        displaylabel_blood.grid(row=1, column=6, padx=5, pady=5)
        displaylabel_birthmark.grid(row=1, column=7, padx=5, pady=5)
        displaylabel_medical.grid(row=1, column=8, padx=5, pady=5)
        displaylabel_camp.grid(row=1, column=9, padx=5, pady=5)
        displaylabel_dateofarrival.grid(row=1, column=10, padx=5, pady=5)

        root2.mainloop()

        con.commit()
        con.close()

    #######################################################################################################################

    window = Tk()
    window.title("Camp Information")
    window.geometry("1500x900")
    window.config(bg="snow")
    frame1 = Frame(window)
    frame1.pack()
    heading_label = Label(frame1, text="Camp Information Portal", bg="snow", fg="black", font=("Helvetica", 28))
    name_label = Label(frame1, text="NAME", bg="snow", fg="black", font=("Helvetica", 15))
    address_label = Label(frame1, text="ADDRESS", bg="snow", fg="black", font=("Helvetica", 15))
    caddress_label = Label(frame1, text="CORRESPONDING ADDRESS", bg="snow", fg="black", font=("Helvetica", 15))
    phone1_label = Label(frame1, text="PHONE NUMBER", bg="snow", fg="black", font=("Helvetica", 15))
    phone2_label = Label(frame1, text="ADDITIONAL PHONE NUMBER", bg="snow", fg="black", font=("Helvetica", 15))
    blood_label = Label(frame1, text="BLOOD GROUP", bg="snow", fg="black", font=("Helvetica", 15))
    birthmrk_label = Label(frame1, text="BIRTH MARK", bg="snow", fg="black", font=("Helvetica", 15))
    dob_label = Label(frame1, text="DATE OF BIRTH", bg="snow", fg="black", font=("Helvetica", 15))
    adhar_label = Label(frame1, text="ADHAR CARD NUMBER", bg="snow", fg="black", font=("Helvetica", 15))
    medical_label = Label(frame1, text="MEDICAL CONDITION", bg="snow", fg="black", font=("Helvetica", 15))
    camp_label = Label(frame1, text="CAMP NUMBER", bg="snow", fg="black", font=("Helvetica", 15))
    date_label = Label(frame1, text="DATE OF ARRIVAL", bg="snow", fg="black", font=("Helvetica", 15))
    enterbutton = Button(frame1, text="ENTER", bg="azure", fg="black", font=("Helvetica", 15), command=submit)
    showdatabutton = Button(frame1, text="SHOW DATA", bg="azure", fg="black", font=("Helvetica", 15), command=showdata)

    input_name = StringVar()
    entry_name = Entry(frame1, textvariable=input_name)

    input_address = StringVar()
    entry_address = Entry(frame1, textvariable=input_address)

    input_caddress = StringVar()
    entry_caddress = Entry(frame1, textvariable=input_caddress)

    input_phone1 = StringVar()
    entry_phone1 = Entry(frame1, textvariable=input_phone1)

    input_phone2 = StringVar()
    entry_phone2 = Entry(frame1, textvariable=input_phone2)

    input_adhar = StringVar()
    entry_adhar = Entry(frame1, textvariable=input_adhar)

    input_dob = StringVar()
    entry_dob = Entry(frame1, textvariable=input_dob)

    input_blood = StringVar()
    entry_blood = Entry(frame1, textvariable=input_blood)

    input_birthmark = StringVar()
    entry_birthmark = Entry(frame1, textvariable=input_birthmark)

    input_medical = StringVar()
    entry_medical = Entry(frame1, textvariable=input_medical)

    input_camp = StringVar()
    entry_camp = Entry(frame1, textvariable=input_camp)

    input_dateofarrival = StringVar()
    entry_dateofarrival = Entry(frame1, textvariable=input_dateofarrival)

    heading_label.grid(row=0, column=1, padx=5, pady=5, ipadx=5, ipady=5, columnspan=2)
    name_label.grid(row=1, column=0, padx=5, pady=5, ipadx=5, ipady=5)
    entry_name.grid(row=1, column=1, padx=5, pady=5, ipadx=5, ipady=5)
    address_label.grid(row=2, column=0, padx=5, pady=5, ipadx=5, ipady=5)
    entry_address.grid(row=2, column=1, padx=5, pady=5, ipadx=5, ipady=5)
    caddress_label.grid(row=2, column=2, padx=5, pady=5, ipadx=5, ipady=5)
    entry_caddress.grid(row=2, column=3, padx=5, pady=5, ipadx=5, ipady=5)
    phone1_label.grid(row=3, column=0, padx=5, pady=5, ipadx=5, ipady=5)
    entry_phone1.grid(row=3, column=1, padx=5, pady=5, ipadx=5, ipady=5)
    phone2_label.grid(row=3, column=2, padx=5, pady=5, ipadx=5, ipady=5)
    entry_phone2.grid(row=3, column=3, padx=5, pady=5, ipadx=5, ipady=5)
    adhar_label.grid(row=4, column=0, padx=5, pady=5, ipadx=5, ipady=5)
    entry_adhar.grid(row=4, column=1, padx=5, pady=5, ipadx=5, ipady=5)
    dob_label.grid(row=5, column=0, padx=5, pady=5, ipadx=5, ipady=5)
    entry_dob.grid(row=5, column=1, padx=5, pady=5, ipadx=5, ipady=5)
    blood_label.grid(row=6, column=0, padx=5, pady=5, ipadx=5, ipady=5)
    entry_blood.grid(row=6, column=1, padx=5, pady=5, ipadx=5, ipady=5)
    birthmrk_label.grid(row=7, column=0, padx=5, pady=5, ipadx=5, ipady=5)
    entry_birthmark.grid(row=7, column=1, padx=5, pady=5, ipadx=5, ipady=5)
    medical_label.grid(row=8, column=0, padx=5, pady=5, ipadx=5, ipady=5)
    entry_medical.grid(row=8, column=1, padx=5, pady=5, ipadx=5, ipady=5)
    camp_label.grid(row=9, column=0, padx=5, pady=5, ipadx=5, ipady=5)
    entry_camp.grid(row=9, column=1, padx=5, pady=5, ipadx=5, ipady=5)
    date_label.grid(row=10, column=0, padx=5, pady=5, ipadx=5, ipady=5)
    entry_dateofarrival.grid(row=10, column=1, padx=5, pady=5, ipadx=5, ipady=5)
    enterbutton.grid(row=11, columnspan=5, column=0, padx=5, pady=5, ipadx=5, ipady=5)
    showdatabutton.grid(row=12, columnspan=5, column=0, padx=5, pady=5, ipadx=5, ipady=5)

    # To save the file automatically
    con.commit()
    con.close()
    window.mainloop()

campinformation()