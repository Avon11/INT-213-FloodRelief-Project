from tkinter import *
import sqlite3

def deathinformation():
    # connect database
    con = sqlite3.connect('death_database.db')

    # create cursor
    c = con.cursor()

    # create table

    '''c.execute(""" CREATE TABLE death (
        name text,
        address text,
        phone1 integer,
        adhar integer,
        dob text,
        birthmark text,
        deathplace text,
        dateofdeath text
        )""")
    '''

    def submit():
        # connect database
        con = sqlite3.connect('death_database.db')

        # create cursor
        c = con.cursor()

        # Insert into table
        c.execute("INSERT INTO death VALUES(:name , "
                  ":address ,"
                  ":phone1 , "
                  ":adhar ,"
                  ":dob ,"
                  ":birthmark ,"
                  ":deathplace ,"
                  ":dateofdeath)",

            {
                'name': input_name.get(),
                'address': input_address.get(),
                'phone1': input_phone1.get(),
                'adhar': input_adhar.get(),
                'dob': input_dob.get(),
                'birthmark': input_birthmark.get(),
                'deathplace': input_birthmark.get(),
                'dateofdeath': input_dateofdeath.get()

            })

        con.commit()
        con.close()
        # clear the text boxes
        entry_name.delete(0, END)
        entry_address.delete(0, END)
        entry_phone1.delete(0, END)
        entry_adhar.delete(0, END)
        entry_dob.delete(0, END)
        entry_birthmark.delete(0, END)
        entry_deathplace.delete(0, END)
        entry_dateofdeath.delete(0, END)

    # For showing data of death
    def showdata():
        root2 = Tk()
        root2.geometry("1500x900")
        root2.config(bg="bisque2")
        # connect database
        con= sqlite3.connect('death_database.db')
        # create cursor
        c = con.cursor()
        # to display the database
        c.execute('SELECT * from death')
        record = c.fetchall()

        # loop through records
        print_data_name = ''
        print_data_address = ''
        print_data_phone1 = ''
        print_data_adhar = ''
        print_data_dob = ''
        print_data_birthmark = ''
        print_data_deathplace = ''
        print_data_dateofdeath = ''

        for records in record:
            print_data_name += str(records[0]) + " \n"
            print_data_address += str(records[1]) + "\n"
            print_data_phone1 += str(records[2]) + "\n"
            print_data_adhar += str(records[3]) + "\n"
            print_data_dob += str(records[4]) + "\n"
            print_data_birthmark += str(records[5]) + "\n"
            print_data_deathplace += str(records[6]) + "\n"
            print_data_dateofdeath += str(records[7]) + "\n"

        displaylabel_name = Label(root2, text=print_data_name, bg="bisque2", fg="black", font=("Helvetica", 15))
        displaylabel_address = Label(root2, text=print_data_address, bg="bisque2", fg="black", font=("Helvetica", 15))
        displaylabel_phone1 = Label(root2, text=print_data_phone1, bg="bisque2", fg="black", font=("Helvetica", 15))
        displaylabel_adhar = Label(root2, text=print_data_adhar, bg="bisque2", fg="black", font=("Helvetica", 15))
        displaylabel_dob = Label(root2, text=print_data_dob, bg="bisque2", fg="black", font=("Helvetica", 15))
        displaylabel_birthmark = Label(root2, text=print_data_birthmark, bg="bisque2", fg="black",
                                       font=("Helvetica", 15))
        displaylabel_deathplace= Label(root2, text=print_data_deathplace, bg="bisque2", fg="black",
                                       font=("Helvetica", 15))
        displaylabel_dateofdeath = Label(root2, text=print_data_dateofdeath, bg="bisque2", fg="black",
                                        font=("Helvetica", 15))


        Label(root2, text="Name", bg="bisque2", fg="black", font=("Helvetica", 16)).grid(row=0, column=1, padx=5,
                                                                                         pady=3)
        Label(root2, text="Address", bg="bisque2", fg="black", font=("Helvetica", 16)).grid(row=0, column=2, padx=5,
                                                                                            pady=3)

        Label(root2, text="Phone number 1", bg="bisque2", fg="black", font=("Helvetica", 16)).grid(row=0, column=3,
                                                                                                   padx=5, pady=3)
        Label(root2, text="Adhar Card ", bg="bisque2", fg="black", font=("Helvetica", 16)).grid(row=0, column=4,
                                                                                                padx=5, pady=3)
        Label(root2, text="Date of birth", bg="bisque2", fg="black", font=("Helvetica", 16)).grid(row=0, column=5,
                                                                                                  padx=5, pady=3)
        Label(root2, text="Birthmark", bg="bisque2", fg="black", font=("Helvetica", 16)).grid(row=0, column=6, padx=5,
                                                                                              pady=3)
        Label(root2, text="Death Place.", bg="bisque2", fg="black", font=("Helvetica", 16)).grid(row=0, column=7,
                                                                                               padx=5, pady=3)
        Label(root2, text="Date of Death", bg="bisque2", fg="black", font=("Helvetica", 16)).grid(row=0, column=8,
                                                                                                    padx=5, pady=3)

        displaylabel_name.grid(row=1, column=1, padx=5, pady=5)
        displaylabel_address.grid(row=1, column=2, padx=5, pady=5)
        displaylabel_phone1.grid(row=1, column=3, padx=5, pady=5)
        displaylabel_adhar.grid(row=1, column=4, padx=5, pady=5)
        displaylabel_dob.grid(row=1, column=5, padx=5, pady=5)
        displaylabel_birthmark.grid(row=1, column=6, padx=5, pady=5)
        displaylabel_deathplace.grid(row=1, column=7, padx=5, pady=5)
        displaylabel_dateofdeath.grid(row=1, column=8, padx=5, pady=5)

        root2.mainloop()

        con.commit()
        con.close()

    #######################################################################################################################

    window = Tk()
    window.title("Death Information")
    window.geometry("1500x1000")
    window.config(bg="snow")
    frame1 = Frame(window)
    frame1.pack()
    heading_label = Label(frame1, text="Death Information Portal", bg="snow", fg="black", font=("Helvetica", 50),relief="raised")
    name_label = Label(frame1, text="FULL NAME", bg="snow", fg="black", font=("Helvetica", 16))
    address_label = Label(frame1, text="ADDRESS", bg="snow", fg="black", font=("Helvetica", 16))
    phone1_label = Label(frame1, text="PHONE NUMBER", bg="snow", fg="black", font=("Helvetica", 16))
    birthmrk_label = Label(frame1, text="BIRTH MARK", bg="snow", fg="black", font=("Helvetica", 16))
    dob_label = Label(frame1, text="DATE OF BIRTH", bg="snow", fg="black", font=("Helvetica", 16))
    adhar_label = Label(frame1, text="ADHAR CARD NUMBER", bg="snow", fg="black", font=("Helvetica", 16))
    deathplace_label = Label(frame1, text="DEATH PLACE", bg="snow", fg="black", font=("Helvetica", 16))
    date_label = Label(frame1, text="DATE OF DEATH", bg="snow", fg="black", font=("Helvetica", 16))
    enterbutton = Button(frame1, text="ENTER", bg="green", fg="black", font=("Helvetica", 16), command=submit)
    showdatabutton = Button(frame1, text="SHOW DATA", bg="yellow", fg="black", font=("Helvetica", 16), command= showdata)

    input_name = StringVar()
    entry_name = Entry(frame1, textvariable=input_name)

    input_address = StringVar()
    entry_address = Entry(frame1, textvariable=input_address)

    input_phone1 = StringVar()
    entry_phone1 = Entry(frame1, textvariable=input_phone1)

    input_adhar = StringVar()
    entry_adhar = Entry(frame1, textvariable=input_adhar)

    input_dob = StringVar()
    entry_dob = Entry(frame1, textvariable=input_dob)

    input_birthmark = StringVar()
    entry_birthmark = Entry(frame1, textvariable=input_birthmark)

    input_deathplace = StringVar()
    entry_deathplace = Entry(frame1, textvariable=input_deathplace)

    input_dateofdeath = StringVar()
    entry_dateofdeath = Entry(frame1, textvariable=input_dateofdeath)

    heading_label.grid(row=0, column=0, padx=0, pady=5, ipadx=5, ipady=5, columnspan=2)
    name_label.grid(row=1, column=0, padx=5, pady=5, ipadx=5, ipady=5)
    entry_name.grid(row=1, column=1, padx=5, pady=5, ipadx=5, ipady=5)
    address_label.grid(row=2, column=0, padx=5, pady=5, ipadx=5, ipady=5)
    entry_address.grid(row=2, column=1, padx=5, pady=5, ipadx=5, ipady=5)
    phone1_label.grid(row=3, column=0, padx=5, pady=5, ipadx=5, ipady=5)
    entry_phone1.grid(row=3, column=1, padx=5, pady=5, ipadx=5, ipady=5)
    adhar_label.grid(row=4, column=0, padx=5, pady=5, ipadx=5, ipady=5)
    entry_adhar.grid(row=4, column=1, padx=5, pady=5, ipadx=5, ipady=5)
    dob_label.grid(row=5, column=0, padx=5, pady=5, ipadx=5, ipady=5)
    entry_dob.grid(row=5, column=1, padx=5, pady=5, ipadx=5, ipady=5)
    birthmrk_label.grid(row=7, column=0, padx=5, pady=5, ipadx=5, ipady=5)
    entry_birthmark.grid(row=7, column=1, padx=5, pady=5, ipadx=5, ipady=5)
    deathplace_label.grid(row=9, column=0, padx=5, pady=5, ipadx=5, ipady=5)
    entry_deathplace.grid(row=9, column=1, padx=5, pady=5, ipadx=5, ipady=5)
    date_label.grid(row=10, column=0, padx=5, pady=5, ipadx=5, ipady=5)
    entry_dateofdeath.grid(row=10, column=1, padx=5, pady=5, ipadx=5, ipady=5)
    enterbutton.grid(row=11, columnspan=5, column=0, padx=5, pady=5, ipadx=5, ipady=5)
    showdatabutton.grid(row=11, columnspan=2, column=1, padx=5, pady=5, ipadx=5, ipady=5)
    btn = Button(window,text="close window",bg="red",font=("Helvetica", 16),relief="sunken",command=window.destroy).pack()
    # To save the file automatically
    con.commit()
    con.close()
    window.mainloop()


deathinformation()
