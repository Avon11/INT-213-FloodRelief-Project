from tkinter import *
import sqlite3

def donation():
    # create table
    '''
    c.execute(""" CREATE TABLE payment (
        name text,
        address text,
        email text,
        contactno integer,
        amount integer
        )""")
    '''
    # connect database
    con = sqlite3.connect('payment_database.db')

    # create cursor
    c = con.cursor()
    #####################################################################################################################
    window1 = Tk()
    window1.title("DONATION PAGE")
    window1.geometry("1500x800")
    window1.configure(bg="bisque2")
    frame1 = Frame(window1, bg="bisque2")
    frame1.pack()

    l1 = Label(frame1, text="GREAT OPPORTUNITIES TO HELP OTHER, STEP OUT AND DONATE HERE!", bg="bisque2", fg="black",
               font=("Helvetica", 28))
    l2 = Label(frame1, text="Pay Online", bg="bisque2", fg="green", font=("Helvetica", 25))
    l3 = Label(frame1, text="NOTE:WE ONLY ACCEPT ONLINE DONATION", bg="bisque2", fg="red", font=("Helvetica", 15))

    v2 = IntVar()
    radiobutton1 = Radiobutton(frame1, text="Credit Card", fg="black", bg="LightCyan3", variable=v2, value=1, height=2,
                               width=15)
    radiobutton2 = Radiobutton(frame1, text="Debit Card", fg="black", bg="LightCyan3", variable=v2, value=2, height=2,
                               width=15)

    l1.grid(row=1, column=1)
    l2.grid(row=2, column=1)
    l3.grid(row=3, column=1)

    radiobutton1.grid(row=4, column=1, padx=5, pady=5)
    radiobutton2.grid(row=5, column=1, padx=5, pady=5)

    frame2 = Frame(window1, bg="bisque2")
    frame2.pack()
    l4 = Label(frame2, text="CARD NUMBER", bg="bisque2", fg="black", font=("Helvetica", 15))
    numbercard = StringVar()
    cardnumber = Entry(frame2, textvariable=numbercard)

    l5 = Label(frame2, text="Expiry date", bg="bisque2", fg="black", font=("Helvetica", 15))
    expirycard = StringVar()
    expirydate = Entry(frame2, textvariable=expirycard)

    l6 = Label(frame2, text="CVV", bg="bisque2", fg="black", font=("Helvetica", 15))
    cvvcard = StringVar()
    cvvnumber = Entry(frame2, textvariable=cvvcard)

    l4.grid(row=0, column=0)
    cardnumber.grid(row=0, column=1, padx=5, pady=5)
    l5.grid(row=1, column=0)
    expirydate.grid(row=1, column=1, padx=5, pady=5)
    l6.grid(row=2, column=0)
    cvvnumber.grid(row=2, column=1, padx=5, pady=5)

    frame3 = Frame(window1, bg="black")
    frame3.pack()
    canvas = Canvas(frame3, width=1500, height=1, bg="black")
    canvas.pack()
    canvas.create_line(300, 35, 300, 200, dash=(5, 2))

    ###################################################################################################################

    def submit():
        # connect database
        con = sqlite3.connect('payment_database.db')

        # create cursor
        c = con.cursor()

        # Insert into table
        c.execute("INSERT INTO payment VALUES(:name, :address, :contact, :email, :amount)",

                  {
                      'name': name.get(),
                      'address': address.get(),
                      'contact': contact.get(),
                      'email': email.get(),
                      'amount': amount.get()
                  })

        con.commit()
        con.close()
        # clear the text boxes
        name.delete(0, END)
        address.delete(0, END)
        contact.delete(0, END)
        email.delete(0, END)
        amount.delete(0, END)
        cardnumber.delete(0, END)
        cvvnumber.delete(0, END)
        expirydate.delete(0, END)

    # show data function

    def showdata():
        root1 = Tk()
        root1.geometry("1500x900")
        root1.config(bg="bisque2")
        root1.title("Donation Database")
        # connect database
        con = sqlite3.connect('payment_database.db')
        # create cursor
        c = con.cursor()
        # to display the database
        c.execute("SELECT *,oid from payment ORDER BY amount desc")
        record = c.fetchall()

        # loop through records
        print_data_name = ''
        print_data_address = ''
        print_data_contact = ''
        print_data_email = ''
        print_data_amount = ''

        for records in record:
            print_data_name += str(records[0]) + " \n"
            print_data_address += str(records[1]) + "\n"
            print_data_contact += str(records[2]) + "\n"
            print_data_email += str(records[3]) + "\n"
            print_data_amount += str(records[4]) + "\n"

        displaylabel_name = Label(root1, text=print_data_name, bg="bisque2", fg="black", font=("Helvetica", 15))
        displaylabel_address = Label(root1, text=print_data_address, bg="bisque2", fg="black", font=("Helvetica", 15))
        displaylabel_contact = Label(root1, text=print_data_contact, bg="bisque2", fg="black", font=("Helvetica", 15))
        displaylabel_email = Label(root1, text=print_data_email, bg="bisque2", fg="black", font=("Helvetica", 15))
        displaylabel_amount = Label(root1, text=print_data_amount, bg="bisque2", fg="black", font=("Helvetica", 15))

        Label(root1, text="Name", bg="bisque2", fg="black", font=("Helvetica", 20)).grid(row=0, column=1, padx=10,
                                                                                         pady=10)
        Label(root1, text="Address", bg="bisque2", fg="black", font=("Helvetica", 20)).grid(row=0, column=2, padx=10,
                                                                                            pady=10)
        Label(root1, text="Contact Number", bg="bisque2", fg="black", font=("Helvetica", 20)).grid(row=0, column=3,padx=10, pady=10)
        Label(root1, text="Email", bg="bisque2", fg="black", font=("Helvetica", 20)).grid(row=0, column=4, padx=10,pady=10)
        Label(root1, text="Amount(In Rs)", bg="bisque2", fg="black", font=("Helvetica", 20)).grid(row=0, column=5,padx=10, pady=10)

        displaylabel_name.grid(row=1, column=1, padx=10, pady=10)
        displaylabel_address.grid(row=1, column=2, padx=10, pady=10)
        displaylabel_contact.grid(row=1, column=3, padx=10, pady=10)
        displaylabel_email.grid(row=1, column=4, padx=10, pady=10)
        displaylabel_amount.grid(row=1, column=5, padx=10, pady=10)
        root1.mainloop()

        con.commit()
        con.close()

    #######################################################################################################################

    frame4 = Frame(window1, bg="bisque2")
    frame4.pack()

    basiclabel = Label(frame4, text="BASIC INFORMATION", bg="bisque2", fg="black", font=("Helvetica", 25))

    amountlabel = Label(frame4, text="Amount", bg="bisque2", fg="black", font=("Helvetica", 15))
    amounte = StringVar()
    amount = Entry(frame4, textvariable=amounte)

    namelabel = Label(frame4, text="NAME", bg="bisque2", fg="black", font=("Helvetica", 15))
    inputname = StringVar()
    name = Entry(frame4, textvariable=inputname)

    addlabel = Label(frame4, text="ADDRESS", bg="bisque2", fg="black", font=("Helvetica", 15))
    inputadd = StringVar()
    address = Entry(frame4, textvariable=inputadd)

    emaillabel = Label(frame4, text="Email", bg="bisque2", fg="black", font=("Helvetica", 15))
    inputemail = StringVar()
    email = Entry(frame4, textvariable=inputemail)

    contactlabel = Label(frame4, text="Contact No.", bg="bisque2", fg="black", font=("Helvetica", 15))
    inputcontact = StringVar()
    contact = Entry(frame4, textvariable=inputcontact)

    enterbutton = Button(frame4, text=" DONATE ", height=2, width=17, bg="PaleGreen2", fg="black",font=("Helvetica", 10), command=submit)

    basiclabel.grid(row=0, column=1, padx=10, pady=10)
    namelabel.grid(row=1, column=0, padx=5, pady=5)
    name.grid(row=1, column=1, padx=5, pady=5)
    addlabel.grid(row=2, column=0, padx=5, pady=5)
    address.grid(row=2, column=1, padx=5, pady=5)
    emaillabel.grid(row=3, column=0, padx=5, pady=5)
    email.grid(row=3, column=1, padx=5, pady=5)
    contactlabel.grid(row=4, column=0, padx=5, pady=5)
    contact.grid(row=4, column=1, padx=5, pady=5)
    amountlabel.grid(row=5, column=0)
    amount.grid(row=5, column=1, padx=5, pady=5)
    enterbutton.grid(row=6, column=1, ipadx=5, ipady=5, padx=5, pady=5)

    # Display data button
    displaydata = Button(frame4, text="See Data", height=2, width=17, bg="azure2", fg="black", font=("Helvetica", 10),command=showdata)
    displaydata.grid(row=7, column=1, columnspan=2, ipadx=5, ipady=5, padx=5, pady=5)

    # To save the file automatically
    con.commit()
    con.close()

    window1.mainloop()

donation()